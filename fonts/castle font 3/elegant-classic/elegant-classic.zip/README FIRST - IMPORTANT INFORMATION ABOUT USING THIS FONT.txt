By using this font, you agree to comply with the license terms stated above.

Hello Imaginatype font downloader,
Please read this carefully before installing the font. By installing or using this font, you agree to the Product Usage Agreement:
    • This font is for PERSONAL USE ONLY; COMMERCIAL USE IS NOT ALLOWED.
    • Here is the link to purchase commercial license:  https://www.creativefabrica.com/product/elegant-classic-signature/ref/1677209/?sharedfrom=pdp
    • For further information, detailed commercial license or custom license please contact us at: imaginatype.studio@gmail.com 
    • Any donation are very appreciated. Paypal account for donation : https://paypal.me/imaginatype

Bahasa Indonesia
Halo pengunduh font Imaginatype,
Harap baca dengan seksama sebelum menginstal font ini. Dengan menginstal atau menggunakan font ini, Anda menyetujui Perjanjian Penggunaan Produk berikut:
    • Font ini hanya untuk PENGGUNAAN PRIBADI; PENGGUNAAN KOMERSIAL TIDAK DIPERBOLEHKAN.
    • Berikut tautan untuk membeli lisensi komersial: https://www.creativefabrica.com/product/elegant-classic-signature/ref/1677209/?sharedfrom=pdp
    • Untuk informasi lebih lanjut, lisensi komersial secara detail, atau lisensi khusus, silakan hubungi kami di: imaginatype.studio@gmail.com
    • Donasi sangat kami hargai. Akun PayPal untuk donasi: https://paypal.me/imaginatype